package main

// The OSS tool depends on this file with this content. If you need to change
// it, change the tool too.

const version = "2.2.4"
